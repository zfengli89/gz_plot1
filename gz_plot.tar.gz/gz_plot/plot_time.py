# coding:utf-8

import csv
from pylab import *
zhfont = mpl.font_manager.FontProperties(fname='/home/sugo/ch_ziti/simfang.ttf')
mpl.rcParams['axes.unicode_minus'] = False


csvfile = open('estab_time.csv','rb')
reader = csv.reader(csvfile)
labels = []
quants = []
N = 20
cnt = 0
for line in reader:
    cnt = cnt + 1
    quants.append(line[1])
    unicode_str = line[0].decode('utf-8')
    labels.append(unicode_str)
    if cnt == N:
        break
csvfile.close()

print labels, quants
print type(quants[1])


lenth = len(labels)
width = 0.4
ind = np.linspace(0.5,lenth-0.5,lenth)
# make a square figure
fig = plt.figure(1, figsize=(12,6))
ax  = fig.add_subplot(111)
# Bar Plot
ax.bar(ind-width/2,quants,width,color='coral')

# Set the ticks on x-axis
ax.set_xticks(ind)
ax.set_xticklabels(labels,rotation=90,fontproperties=zhfont)
# labels
ax.set_xlabel('')
ax.set_ylabel(u'数目',fontproperties=zhfont)
# title
ax.set_title('Top 10 GDP Countries', bbox={'facecolor':'0.8', 'pad':5})
plt.show()
