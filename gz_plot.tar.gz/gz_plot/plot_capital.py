# coding:utf-8

import csv
from pylab import *
zhfont = mpl.font_manager.FontProperties(fname='/home/sugo/ch_ziti/simfang.ttf')
mpl.rcParams['axes.unicode_minus'] = False

labels = ['null','(0-10]', '(10-50]', '(50-100]', '(100-500]', '(500-1000]', '(1000-5000]', '(5000-10000]', '(10000-..)']
quants = [0,0,0,0,0,0,0,0,0]

csvfile = open('last_capital.csv','rb')
reader = csv.reader(csvfile)


for line in reader:
    str_cnt = line[1]
    int_cnt = int(str_cnt)
    if line[0] != '':
        int_money = int(line[0])
        #print line[0],line[1]
        if int_money > 0 and int_money <= 10:
            print int_cnt
            quants[1] =  quants[1] + int_cnt
        elif int_money >10 and int_money <=50:
            quants[2] = quants[2] + int_cnt
        elif int_money >50 and int_money <=100:
            quants[3] = quants[3] + int_cnt
        elif int_money >100 and int_money <=500:
            quants[4] = quants[4] + int_cnt
        elif int_money >500 and int_money <=1000:
            quants[5] = quants[5] + int_cnt
        elif int_money >1000 and int_money <=5000:
            quants[6] = quants[6] + int_cnt
        elif int_money >5000 and int_money <=10000:
            quants[7] = quants[7] + int_cnt
        else:
            quants[8] = quants[8] + int_cnt
    else:
        quants[0] = quants[0] + int_cnt




csvfile.close()

#print labels, quants
#print type(quants[1])



lenth = len(labels)
width = 0.4
ind = np.linspace(0.5,lenth-0.5,lenth)
# make a square figure
fig = plt.figure(1, figsize=(12,6))
ax  = fig.add_subplot(111)
# Bar Plot
ax.bar(ind-width/2,quants,width,color='coral')

# Set the ticks on x-axis
ax.set_xticks(ind)
ax.set_xticklabels(labels,rotation=0,fontproperties=zhfont)
# labels
ax.set_xlabel('Country')
ax.set_ylabel('GDP (Billion US dollar)')
# title
ax.set_title('Top 10 GDP Countries', bbox={'facecolor':'0.8', 'pad':5})
plt.show()

